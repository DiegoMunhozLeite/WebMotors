package metodos;

import java.io.File;
import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Metodos {

	WebDriver driver;

	/**
	 * Metodo para abrir o navigator da web
	 * 
	 * @author Diego
	 */

	public void abrirNavegador(String site) {
		try {
			System.setProperty("webdriver.chrome.driver", "./Drivers/chromedriver.exe");
			driver = new ChromeDriver();
			driver.get(site);
			driver.manage().timeouts().implicitlyWait(8, TimeUnit.SECONDS);
			driver.manage().window().maximize();

		} catch (Exception e) {
			System.err.println("========= error ao abrir navegador =====" + e.getMessage());
		}

	}

	/**
	 * Metodo para escrever em um elemento da web
	 * 
	 * @param elemento
	 * @param texto
	 */

	public void escrever(By elemento, String texto) {
		try {
			driver.findElement(elemento).sendKeys(texto);

		} catch (Exception e) {
			System.err.println("========= error ao escrever em um elemento =====" + e.getMessage());
		}

	}

	/**
	 * Metodo para dar uma pausa na pagina
	 * 
	 * @author Diego
	 */
	public void pausa(int tempo) {
		try {
			Thread.sleep(tempo);

		} catch (Exception e) {
			System.err.println("========= error ao escrever em um elemento =====" + e.getMessage());
		}
	}

	/**
	 * Metodo para clicar em um elemento da web
	 * 
	 * @param elemento
	 * @author Diego
	 */
	public void clicar(By elemento) {
		try {
			driver.findElement(elemento).click();

		} catch (Exception e) {
			System.err.println("========= error ao clicar em um elemento =====" + e.getCause());
			System.err.println("========= error ao clicar em um elemento =====" + e.getMessage());
		}

	}

	/**
	 * Metodo para tirar screenshot da tela
	 * 
	 * @author Diego
	 * @param nome
	 * @throws IOException
	 */
	public void foto(String nome) throws IOException {
		try {
			TakesScreenshot foto = ((TakesScreenshot) driver);
			File srcFile = foto.getScreenshotAs(OutputType.FILE);
			File destFile = new File("./Evidencia/" + nome + ".png");
			FileUtils.copyFile(srcFile, destFile);

		} catch (Exception e) {
			System.err.println("========= error ao tirar foto =====" + e.getMessage());
		}

	}

	/**
	 * Metodo para fechar a pagina da web apos finalizar o teste
	 * 
	 * @author DiegoS
	 */
	public void fechar() {
		try {

		} catch (Exception e) {
			System.err.println("========= error ao echar a pagina =====" + e.getMessage());
		}
	}
}
