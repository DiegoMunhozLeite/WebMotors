package steps;

import java.io.IOException;

import elementos.Elementos;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import metodos.Metodos;

public class WebMotrors {

	Metodos metodo = new Metodos();
	Elementos el = new Elementos();
	

	@Given("que eu esteja no {string}")
	public void que_eu_esteja_no(String site) {
		metodo.abrirNavegador(site);
		metodo.clicar(el.getKookie());
	}

	@Given("realize uma pesquisa de de um veiculo")
	public void realize_uma_pesquisa_de_de_um_veiculo() {
		metodo.escrever(el.getPesquisa(), "Honda");
		metodo.pausa(3000);
	}

	@When("clicar em pesquisar")
	public void clicar_em_pesquisar() throws IOException {

		metodo.clicar(el.getModelo());
		metodo.foto("carro");

	}

	@Then("apresentar veiculo conforme a pesquisa")
	public void apresentar_veiculo_conforme_a_pesquisa() {

	}

}
