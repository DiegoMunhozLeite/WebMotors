package elementos;

import org.openqa.selenium.By;

public class Elementos {
	
	private By acesso = By.xpath("//*[@id=\"searchBar\"]");
	private By pesquisa = By.id("searchBar");
	private By modelo = By.xpath("/html/body/div[1]/main/div[2]/div/div[1]/div[2]/div/div/div/div/div/div[2]/a[1]/div[2]");
	private By kookie = By.xpath("//*[@id=\"root\"]/div[3]/div[2]/button");
	
	public By getAcesso() {
		return acesso;
	}
	public By getPesquisa() {
		return pesquisa;
	}
	public By getModelo() {
		return modelo;
	}
	public By getKookie() {
		return kookie;
	}
	

}